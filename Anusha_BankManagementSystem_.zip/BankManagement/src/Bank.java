
import java.util.ArrayList;

public class Bank {

    ArrayList<Account> accounts = new ArrayList<>();

    // Add new account
    public void addAccount(Account acc) {
        accounts.add(acc);
        System.out.println("Account Added Successfully");
    }

    // Find account
    public Account findAccount(int accNo) {
        for (Account acc : accounts) {
            if (acc.getAccNo() == accNo) {
                return acc;
            }
        }
        return null;
    }

        }

