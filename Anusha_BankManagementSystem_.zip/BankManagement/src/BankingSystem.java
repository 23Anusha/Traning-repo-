import java.util.Scanner;

public class BankingSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("        WELCOME TO BANKING APPLICATION    ");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Check Balance");
            System.out.println("5. Display All Accounts");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Account No: ");
                    int accNo = sc.nextInt();
                    System.out.print("Name: ");
                    String name = sc.next();
                    System.out.print("Initial Balance: ");
                    double bal = sc.nextDouble();

                    AccountDao.createAccount(
                            new Account(accNo, name, bal)
                    );
                    break;

                case 2:
                    System.out.print("Account No: ");
                    accNo = sc.nextInt();
                    System.out.print("Deposit Amount: ");
                    double dep = sc.nextDouble();

                    AccountDao.deposit(accNo, dep);
                    break;

                case 3:
                    System.out.print("Account No: ");
                    accNo = sc.nextInt();
                    System.out.print("Withdraw Amount: ");
                    double wd = sc.nextDouble();

                    AccountDao.withdraw(accNo, wd);
                    break;

                case 4:
                    System.out.print("Account No: ");
                    accNo = sc.nextInt();

                    AccountDao.checkBalance(accNo);
                    break;

                case 5:
                    AccountDao.displayAllAccounts();
                    break;

                case 6:
                    System.out.println("Exiting Application...");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

        } while (choice != 6);

        sc.close();
    }
}
