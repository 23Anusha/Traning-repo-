import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AccountDao {

    // 🔐 LOGIN
    public static boolean login(String username, String password) {

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // 1️⃣ Create Account
    public static void createAccount(Account acc) {

        try (Connection con = DBConnection.getConnection()) {

            String sql = "INSERT INTO accounts VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, acc.getAccNo());
            ps.setString(2, acc.getName());
            ps.setDouble(3, acc.getBalance());

            ps.executeUpdate();
            System.out.println("Account Created Successfully");

        } catch (Exception e) {
            System.out.println("Account already exists!");
        }
    }

    // 2️⃣ Deposit
    public static void deposit(int accNo, double amount) {

        try (Connection con = DBConnection.getConnection()) {

            String sql = "UPDATE accounts SET balance = balance + ? WHERE acc_no=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDouble(1, amount);
            ps.setInt(2, accNo);

            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("Deposit Successful");
            else
                System.out.println("Account not found");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 3️⃣ Withdraw
    public static void withdraw(int accNo, double amount) {

        try (Connection con = DBConnection.getConnection()) {

            String checkSql = "SELECT balance FROM accounts WHERE acc_no=?";
            PreparedStatement checkPs = con.prepareStatement(checkSql);
            checkPs.setInt(1, accNo);
            ResultSet rs = checkPs.executeQuery();

            if (!rs.next()) {
                System.out.println("Account not found");
                return;
            }

            double balance = rs.getDouble(1);
            if (balance < amount) {
                System.out.println("Insufficient balance");
                return;
            }

            String updateSql = "UPDATE accounts SET balance = balance - ? WHERE acc_no=?";
            PreparedStatement updatePs = con.prepareStatement(updateSql);
            updatePs.setDouble(1, amount);
            updatePs.setInt(2, accNo);
            updatePs.executeUpdate();

            System.out.println("Withdrawal Successful");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 4️⃣ Check Balance
    public static void checkBalance(int accNo) {

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT balance FROM accounts WHERE acc_no=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, accNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next())
                System.out.println("Current Balance: " + rs.getDouble(1));
            else
                System.out.println("Account not found");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 5️⃣ Display All Accounts
    public static void displayAllAccounts() {

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT * FROM accounts";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            System.out.println("AccNo | Name | Balance");
            while (rs.next()) {
                System.out.println(
                        rs.getInt("acc_no") + " | " +
                                rs.getString("name") + " | " +
                                rs.getDouble("balance")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
